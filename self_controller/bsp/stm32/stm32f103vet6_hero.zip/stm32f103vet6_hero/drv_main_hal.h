#ifndef __DRV_MAIN_HAL_H__
#define __DRV_MAIN_HAL_H__

void Error_Handler(void);

#endif
